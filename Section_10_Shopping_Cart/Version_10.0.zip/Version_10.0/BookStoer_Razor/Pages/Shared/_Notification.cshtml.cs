using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookStoer_Razor.Pages.Shared
{
    public class NotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
